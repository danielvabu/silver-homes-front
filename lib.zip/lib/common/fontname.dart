class FontName {
  static const String avenirnext = "avenirnext";
}
