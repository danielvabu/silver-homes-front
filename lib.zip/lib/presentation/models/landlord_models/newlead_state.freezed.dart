// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides

part of 'newlead_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more informations: https://github.com/rrousselGit/freezed#custom-getters-and-methods');

/// @nodoc
class _$NewLeadStateTearOff {
  const _$NewLeadStateTearOff();

  _NewLeadState call(
      {PropertyData? propertyValue,
      required List<PropertyData> propertylist,
      required List<NewLead> newleadlist,
      required String isreferesh}) {
    return _NewLeadState(
      propertyValue: propertyValue,
      propertylist: propertylist,
      newleadlist: newleadlist,
      isreferesh: isreferesh,
    );
  }
}

/// @nodoc
const $NewLeadState = _$NewLeadStateTearOff();

/// @nodoc
mixin _$NewLeadState {
  PropertyData? get propertyValue => throw _privateConstructorUsedError;
  List<PropertyData> get propertylist => throw _privateConstructorUsedError;
  List<NewLead> get newleadlist => throw _privateConstructorUsedError;
  String get isreferesh => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $NewLeadStateCopyWith<NewLeadState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $NewLeadStateCopyWith<$Res> {
  factory $NewLeadStateCopyWith(
          NewLeadState value, $Res Function(NewLeadState) then) =
      _$NewLeadStateCopyWithImpl<$Res>;
  $Res call(
      {PropertyData? propertyValue,
      List<PropertyData> propertylist,
      List<NewLead> newleadlist,
      String isreferesh});
}

/// @nodoc
class _$NewLeadStateCopyWithImpl<$Res> implements $NewLeadStateCopyWith<$Res> {
  _$NewLeadStateCopyWithImpl(this._value, this._then);

  final NewLeadState _value;
  // ignore: unused_field
  final $Res Function(NewLeadState) _then;

  @override
  $Res call({
    Object? propertyValue = freezed,
    Object? propertylist = freezed,
    Object? newleadlist = freezed,
    Object? isreferesh = freezed,
  }) {
    return _then(_value.copyWith(
      propertyValue: propertyValue == freezed
          ? _value.propertyValue
          : propertyValue // ignore: cast_nullable_to_non_nullable
              as PropertyData?,
      propertylist: propertylist == freezed
          ? _value.propertylist
          : propertylist // ignore: cast_nullable_to_non_nullable
              as List<PropertyData>,
      newleadlist: newleadlist == freezed
          ? _value.newleadlist
          : newleadlist // ignore: cast_nullable_to_non_nullable
              as List<NewLead>,
      isreferesh: isreferesh == freezed
          ? _value.isreferesh
          : isreferesh // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc
abstract class _$NewLeadStateCopyWith<$Res>
    implements $NewLeadStateCopyWith<$Res> {
  factory _$NewLeadStateCopyWith(
          _NewLeadState value, $Res Function(_NewLeadState) then) =
      __$NewLeadStateCopyWithImpl<$Res>;
  @override
  $Res call(
      {PropertyData? propertyValue,
      List<PropertyData> propertylist,
      List<NewLead> newleadlist,
      String isreferesh});
}

/// @nodoc
class __$NewLeadStateCopyWithImpl<$Res> extends _$NewLeadStateCopyWithImpl<$Res>
    implements _$NewLeadStateCopyWith<$Res> {
  __$NewLeadStateCopyWithImpl(
      _NewLeadState _value, $Res Function(_NewLeadState) _then)
      : super(_value, (v) => _then(v as _NewLeadState));

  @override
  _NewLeadState get _value => super._value as _NewLeadState;

  @override
  $Res call({
    Object? propertyValue = freezed,
    Object? propertylist = freezed,
    Object? newleadlist = freezed,
    Object? isreferesh = freezed,
  }) {
    return _then(_NewLeadState(
      propertyValue: propertyValue == freezed
          ? _value.propertyValue
          : propertyValue // ignore: cast_nullable_to_non_nullable
              as PropertyData?,
      propertylist: propertylist == freezed
          ? _value.propertylist
          : propertylist // ignore: cast_nullable_to_non_nullable
              as List<PropertyData>,
      newleadlist: newleadlist == freezed
          ? _value.newleadlist
          : newleadlist // ignore: cast_nullable_to_non_nullable
              as List<NewLead>,
      isreferesh: isreferesh == freezed
          ? _value.isreferesh
          : isreferesh // ignore: cast_nullable_to_non_nullable
              as String,
    ));
  }
}

/// @nodoc

class _$_NewLeadState implements _NewLeadState {
  const _$_NewLeadState(
      {this.propertyValue,
      required this.propertylist,
      required this.newleadlist,
      required this.isreferesh});

  @override
  final PropertyData? propertyValue;
  @override
  final List<PropertyData> propertylist;
  @override
  final List<NewLead> newleadlist;
  @override
  final String isreferesh;

  @override
  String toString() {
    return 'NewLeadState(propertyValue: $propertyValue, propertylist: $propertylist, newleadlist: $newleadlist, isreferesh: $isreferesh)';
  }

  @override
  bool operator ==(dynamic other) {
    return identical(this, other) ||
        (other is _NewLeadState &&
            (identical(other.propertyValue, propertyValue) ||
                const DeepCollectionEquality()
                    .equals(other.propertyValue, propertyValue)) &&
            (identical(other.propertylist, propertylist) ||
                const DeepCollectionEquality()
                    .equals(other.propertylist, propertylist)) &&
            (identical(other.newleadlist, newleadlist) ||
                const DeepCollectionEquality()
                    .equals(other.newleadlist, newleadlist)) &&
            (identical(other.isreferesh, isreferesh) ||
                const DeepCollectionEquality()
                    .equals(other.isreferesh, isreferesh)));
  }

  @override
  int get hashCode =>
      runtimeType.hashCode ^
      const DeepCollectionEquality().hash(propertyValue) ^
      const DeepCollectionEquality().hash(propertylist) ^
      const DeepCollectionEquality().hash(newleadlist) ^
      const DeepCollectionEquality().hash(isreferesh);

  @JsonKey(ignore: true)
  @override
  _$NewLeadStateCopyWith<_NewLeadState> get copyWith =>
      __$NewLeadStateCopyWithImpl<_NewLeadState>(this, _$identity);
}

abstract class _NewLeadState implements NewLeadState {
  const factory _NewLeadState(
      {PropertyData? propertyValue,
      required List<PropertyData> propertylist,
      required List<NewLead> newleadlist,
      required String isreferesh}) = _$_NewLeadState;

  @override
  PropertyData? get propertyValue => throw _privateConstructorUsedError;
  @override
  List<PropertyData> get propertylist => throw _privateConstructorUsedError;
  @override
  List<NewLead> get newleadlist => throw _privateConstructorUsedError;
  @override
  String get isreferesh => throw _privateConstructorUsedError;
  @override
  @JsonKey(ignore: true)
  _$NewLeadStateCopyWith<_NewLeadState> get copyWith =>
      throw _privateConstructorUsedError;
}
