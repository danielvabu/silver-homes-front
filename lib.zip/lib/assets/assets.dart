const String urlImages = "assets/images";
const String urlGif = "assets/images/gif";
const String urlIcons = "assets/images/icons";
const String urlCard = "assets/images/card";

class AppAssets {
  String icon = "$urlImages/logo.svg";
  String icsort = "assets/images/ic_sort.png";
  String lease = "assets/images/ic_fnl_leaseagree.png";

  String circleCheck = "assets/images/ic_circle_check.png";
  String navshedule = "assets/images/ic_nav_scheduling.png";
  String icShort = 'assets/images/ic_sort.png';

  String menuLogo = 'assets/images/menu_logo.png';
  String refercheck = "assets/images/ic_fnl_refercheck.png";
  String docvarif = "assets/images/ic_fnl_docvarif.png";
}
