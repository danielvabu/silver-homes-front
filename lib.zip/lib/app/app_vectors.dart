class AppVectors {
//Vector apps

}
